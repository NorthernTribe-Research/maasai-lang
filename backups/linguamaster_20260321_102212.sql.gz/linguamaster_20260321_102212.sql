--
-- PostgreSQL database dump
--

\restrict yX5Mb0W7ZGb9T4dJCy2rjZZvOGQOXkAITcTWFb9SCLN9H9i2AbuNcW8MT1s6A2i

-- Dumped from database version 15.17
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.achievements (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    icon text NOT NULL,
    condition text NOT NULL
);


--
-- Name: achievements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.achievements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: achievements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.achievements_id_seq OWNED BY public.achievements.id;


--
-- Name: activity_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_summaries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date timestamp without time zone NOT NULL,
    activity_type character varying(50) NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    xp_earned integer DEFAULT 0 NOT NULL,
    average_accuracy integer DEFAULT 0 NOT NULL
);


--
-- Name: ai_learning_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_learning_sessions (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    language_id integer NOT NULL,
    session_type text NOT NULL,
    topic text NOT NULL,
    difficulty text NOT NULL,
    ai_teacher_persona text,
    learning_objectives jsonb,
    content_summary jsonb,
    performance_metrics jsonb,
    adaptations jsonb,
    xp_earned integer DEFAULT 0 NOT NULL,
    duration integer,
    is_completed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: ai_learning_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_learning_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_learning_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_learning_sessions_id_seq OWNED BY public.ai_learning_sessions.id;


--
-- Name: ai_session_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_session_contexts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    session_type character varying(50) NOT NULL,
    conversation_history jsonb DEFAULT '[]'::jsonb NOT NULL,
    learning_context jsonb NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.challenges (
    id integer NOT NULL,
    language_id integer NOT NULL,
    prompt text NOT NULL,
    answer text NOT NULL,
    type text NOT NULL,
    difficulty integer DEFAULT 1 NOT NULL,
    xp_reward integer DEFAULT 10 NOT NULL
);


--
-- Name: challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.challenges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: challenges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.challenges_id_seq OWNED BY public.challenges.id;


--
-- Name: curricula; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.curricula (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    target_language character varying(50) NOT NULL,
    lessons jsonb DEFAULT '[]'::jsonb NOT NULL,
    generated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: daily_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_challenges (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    challenge_id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: daily_challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_challenges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_challenges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_challenges_id_seq OWNED BY public.daily_challenges.id;


--
-- Name: enhanced_lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enhanced_lessons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    curriculum_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    proficiency_level character varying(20) NOT NULL,
    order_index integer NOT NULL,
    vocabulary jsonb DEFAULT '[]'::jsonb NOT NULL,
    grammar jsonb DEFAULT '[]'::jsonb NOT NULL,
    cultural_content jsonb DEFAULT '[]'::jsonb NOT NULL,
    estimated_duration integer DEFAULT 30 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: exercise_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercise_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exercise_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    user_answer text NOT NULL,
    is_correct boolean NOT NULL,
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    time_taken integer NOT NULL
);


--
-- Name: exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercises (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    question text NOT NULL,
    options jsonb,
    correct_answer text NOT NULL,
    explanation text NOT NULL,
    difficulty integer DEFAULT 5 NOT NULL,
    target_weakness character varying(100),
    target_language character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    flag text NOT NULL,
    description text
);


--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.languages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.languages_id_seq OWNED BY public.languages.id;


--
-- Name: learning_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.learning_conversations (
    id integer NOT NULL,
    session_id integer NOT NULL,
    user_id character varying NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    ai_analysis jsonb,
    feedback text,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: learning_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.learning_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: learning_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.learning_conversations_id_seq OWNED BY public.learning_conversations.id;


--
-- Name: learning_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.learning_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    target_language character varying(50) NOT NULL,
    native_language character varying(50) NOT NULL,
    proficiency_level character varying(20) DEFAULT 'Beginner'::character varying NOT NULL,
    current_xp integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_activity_date timestamp without time zone,
    weaknesses jsonb DEFAULT '[]'::jsonb,
    strengths jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: lesson_completions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lesson_completions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lesson_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    completed_at timestamp without time zone DEFAULT now() NOT NULL,
    performance_metrics jsonb NOT NULL,
    xp_awarded integer DEFAULT 0 NOT NULL,
    time_spent integer DEFAULT 0
);


--
-- Name: lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lessons (
    id integer NOT NULL,
    language_id integer NOT NULL,
    title text NOT NULL,
    description text,
    content text,
    level integer DEFAULT 1 NOT NULL,
    type text NOT NULL,
    xp_reward integer DEFAULT 10 NOT NULL,
    "order" integer NOT NULL,
    duration integer DEFAULT 10 NOT NULL,
    icon text
);


--
-- Name: lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lessons_id_seq OWNED BY public.lessons.id;


--
-- Name: pronunciation_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pronunciation_analyses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    score integer NOT NULL,
    overall_score integer DEFAULT 0 NOT NULL,
    transcript text NOT NULL,
    target_text text NOT NULL,
    problematic_phonemes jsonb DEFAULT '[]'::jsonb NOT NULL,
    overall_feedback text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    analyzed_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: pronunciation_trends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pronunciation_trends (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date timestamp without time zone NOT NULL,
    average_score integer NOT NULL,
    phoneme_scores jsonb DEFAULT '{}'::jsonb NOT NULL,
    improvement_rate integer DEFAULT 0 NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


--
-- Name: stripe_checkout_fulfillments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stripe_checkout_fulfillments (
    id integer NOT NULL,
    session_id character varying(255) NOT NULL,
    user_id character varying NOT NULL,
    checkout_type character varying(64) NOT NULL,
    package_id character varying(32),
    plan character varying(32),
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    fulfillment_payload jsonb,
    last_error text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    fulfilled_at timestamp without time zone
);


--
-- Name: stripe_checkout_fulfillments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stripe_checkout_fulfillments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stripe_checkout_fulfillments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stripe_checkout_fulfillments_id_seq OWNED BY public.stripe_checkout_fulfillments.id;


--
-- Name: user_achievements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_achievements (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    achievement_id integer NOT NULL,
    earned_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_achievements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_achievements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_achievements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_achievements_id_seq OWNED BY public.user_achievements.id;


--
-- Name: user_languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_languages (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    language_id integer NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_languages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_languages_id_seq OWNED BY public.user_languages.id;


--
-- Name: user_lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_lessons (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    lesson_id integer NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    last_accessed timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- Name: user_lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_lessons_id_seq OWNED BY public.user_lessons.id;


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_settings (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    push_notifications boolean DEFAULT false NOT NULL,
    weekly_report boolean DEFAULT true NOT NULL,
    achievement_alerts boolean DEFAULT true NOT NULL,
    streak_reminders boolean DEFAULT true NOT NULL,
    practice_reminders boolean DEFAULT true NOT NULL,
    data_sharing boolean DEFAULT false NOT NULL,
    profile_visibility text DEFAULT 'public'::text NOT NULL,
    show_progress boolean DEFAULT true NOT NULL,
    show_streak boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_settings_id_seq OWNED BY public.user_settings.id;


--
-- Name: user_unit_legendary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_unit_legendary (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    unit_id character varying(64) NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    upgraded_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_unit_legendary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_unit_legendary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_unit_legendary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_unit_legendary_id_seq OWNED BY public.user_unit_legendary.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    username text,
    password text,
    xp integer DEFAULT 0 NOT NULL,
    streak integer DEFAULT 0 NOT NULL,
    hearts integer DEFAULT 5 NOT NULL,
    max_hearts integer DEFAULT 5 NOT NULL,
    gems integer DEFAULT 500 NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    unlimited_hearts boolean DEFAULT false NOT NULL,
    premium_expires_at timestamp without time zone,
    level integer DEFAULT 1 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_active timestamp without time zone DEFAULT now() NOT NULL,
    streak_updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now(),
    is_admin boolean DEFAULT false NOT NULL
);


--
-- Name: voice_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voice_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    conversation_history jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_turns integer DEFAULT 0 NOT NULL,
    xp_awarded integer DEFAULT 0 NOT NULL,
    duration integer DEFAULT 0
);


--
-- Name: xp_gains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.xp_gains (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    profile_id uuid,
    amount integer NOT NULL,
    source character varying(50) NOT NULL,
    source_id character varying(255),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: achievements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.achievements ALTER COLUMN id SET DEFAULT nextval('public.achievements_id_seq'::regclass);


--
-- Name: ai_learning_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_learning_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_learning_sessions_id_seq'::regclass);


--
-- Name: challenges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenges ALTER COLUMN id SET DEFAULT nextval('public.challenges_id_seq'::regclass);


--
-- Name: daily_challenges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenges ALTER COLUMN id SET DEFAULT nextval('public.daily_challenges_id_seq'::regclass);


--
-- Name: languages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages ALTER COLUMN id SET DEFAULT nextval('public.languages_id_seq'::regclass);


--
-- Name: learning_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_conversations ALTER COLUMN id SET DEFAULT nextval('public.learning_conversations_id_seq'::regclass);


--
-- Name: lessons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons ALTER COLUMN id SET DEFAULT nextval('public.lessons_id_seq'::regclass);


--
-- Name: stripe_checkout_fulfillments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkout_fulfillments ALTER COLUMN id SET DEFAULT nextval('public.stripe_checkout_fulfillments_id_seq'::regclass);


--
-- Name: user_achievements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_achievements ALTER COLUMN id SET DEFAULT nextval('public.user_achievements_id_seq'::regclass);


--
-- Name: user_languages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_languages ALTER COLUMN id SET DEFAULT nextval('public.user_languages_id_seq'::regclass);


--
-- Name: user_lessons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_lessons ALTER COLUMN id SET DEFAULT nextval('public.user_lessons_id_seq'::regclass);


--
-- Name: user_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings ALTER COLUMN id SET DEFAULT nextval('public.user_settings_id_seq'::regclass);


--
-- Name: user_unit_legendary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_unit_legendary ALTER COLUMN id SET DEFAULT nextval('public.user_unit_legendary_id_seq'::regclass);


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.achievements (id, name, description, icon, condition) FROM stdin;
\.


--
-- Data for Name: activity_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_summaries (id, profile_id, date, activity_type, count, xp_earned, average_accuracy) FROM stdin;
\.


--
-- Data for Name: ai_learning_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_learning_sessions (id, user_id, language_id, session_type, topic, difficulty, ai_teacher_persona, learning_objectives, content_summary, performance_metrics, adaptations, xp_earned, duration, is_completed, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: ai_session_contexts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_session_contexts (id, user_id, session_type, conversation_history, learning_context, started_at, last_activity_at, expires_at) FROM stdin;
\.


--
-- Data for Name: challenges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.challenges (id, language_id, prompt, answer, type, difficulty, xp_reward) FROM stdin;
\.


--
-- Data for Name: curricula; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.curricula (id, profile_id, target_language, lessons, generated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_challenges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_challenges (id, user_id, challenge_id, date, is_completed, completed_at) FROM stdin;
\.


--
-- Data for Name: enhanced_lessons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enhanced_lessons (id, curriculum_id, title, proficiency_level, order_index, vocabulary, grammar, cultural_content, estimated_duration, created_at) FROM stdin;
\.


--
-- Data for Name: exercise_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercise_submissions (id, exercise_id, profile_id, user_answer, is_correct, submitted_at, created_at, time_taken) FROM stdin;
\.


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercises (id, type, question, options, correct_answer, explanation, difficulty, target_weakness, target_language, created_at) FROM stdin;
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.languages (id, code, name, flag, description) FROM stdin;
1	zh	Mandarin Chinese	🇨🇳	The world's most spoken language
2	es	Spanish	🇪🇸	Vibrant and widely spoken
3	en	English	🇺🇸	The global language of business
4	hi	Hindi	🇮🇳	The beautiful language of India
5	ar	Arabic	🇸🇦	The rich language of the Arab world
\.


--
-- Data for Name: learning_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.learning_conversations (id, session_id, user_id, role, content, ai_analysis, feedback, "timestamp") FROM stdin;
\.


--
-- Data for Name: learning_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.learning_profiles (id, user_id, target_language, native_language, proficiency_level, current_xp, current_streak, longest_streak, last_activity_date, weaknesses, strengths, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lesson_completions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lesson_completions (id, lesson_id, profile_id, completed_at, performance_metrics, xp_awarded, time_spent) FROM stdin;
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lessons (id, language_id, title, description, content, level, type, xp_reward, "order", duration, icon) FROM stdin;
\.


--
-- Data for Name: pronunciation_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pronunciation_analyses (id, profile_id, score, overall_score, transcript, target_text, problematic_phonemes, overall_feedback, "timestamp", analyzed_at) FROM stdin;
\.


--
-- Data for Name: pronunciation_trends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pronunciation_trends (id, profile_id, date, average_score, phoneme_scores, improvement_rate) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (sid, sess, expire) FROM stdin;
\.


--
-- Data for Name: stripe_checkout_fulfillments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stripe_checkout_fulfillments (id, session_id, user_id, checkout_type, package_id, plan, status, fulfillment_payload, last_error, created_at, updated_at, fulfilled_at) FROM stdin;
\.


--
-- Data for Name: user_achievements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_achievements (id, user_id, achievement_id, earned_at) FROM stdin;
\.


--
-- Data for Name: user_languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_languages (id, user_id, language_id, level, progress, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_lessons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_lessons (id, user_id, lesson_id, is_completed, progress, last_accessed, completed_at) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_settings (id, user_id, email_notifications, push_notifications, weekly_report, achievement_alerts, streak_reminders, practice_reminders, data_sharing, profile_visibility, show_progress, show_streak, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_unit_legendary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_unit_legendary (id, user_id, unit_id, attempts, upgraded_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, first_name, last_name, profile_image_url, username, password, xp, streak, hearts, max_hearts, gems, is_premium, unlimited_hearts, premium_expires_at, level, longest_streak, last_active, streak_updated_at, created_at, updated_at, is_admin) FROM stdin;
\.


--
-- Data for Name: voice_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voice_sessions (id, profile_id, started_at, ended_at, conversation_history, total_turns, xp_awarded, duration) FROM stdin;
\.


--
-- Data for Name: xp_gains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.xp_gains (id, user_id, profile_id, amount, source, source_id, "timestamp") FROM stdin;
\.


--
-- Name: achievements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.achievements_id_seq', 1, false);


--
-- Name: ai_learning_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_learning_sessions_id_seq', 1, false);


--
-- Name: challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.challenges_id_seq', 1, false);


--
-- Name: daily_challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_challenges_id_seq', 1, false);


--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.languages_id_seq', 5, true);


--
-- Name: learning_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.learning_conversations_id_seq', 1, false);


--
-- Name: lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lessons_id_seq', 1, false);


--
-- Name: stripe_checkout_fulfillments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stripe_checkout_fulfillments_id_seq', 1, false);


--
-- Name: user_achievements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_achievements_id_seq', 1, false);


--
-- Name: user_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_languages_id_seq', 1, false);


--
-- Name: user_lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_lessons_id_seq', 1, false);


--
-- Name: user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_settings_id_seq', 1, false);


--
-- Name: user_unit_legendary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_unit_legendary_id_seq', 1, false);


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: activity_summaries activity_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_summaries
    ADD CONSTRAINT activity_summaries_pkey PRIMARY KEY (id);


--
-- Name: ai_learning_sessions ai_learning_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_learning_sessions
    ADD CONSTRAINT ai_learning_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_session_contexts ai_session_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_session_contexts
    ADD CONSTRAINT ai_session_contexts_pkey PRIMARY KEY (id);


--
-- Name: challenges challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenges
    ADD CONSTRAINT challenges_pkey PRIMARY KEY (id);


--
-- Name: curricula curricula_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.curricula
    ADD CONSTRAINT curricula_pkey PRIMARY KEY (id);


--
-- Name: daily_challenges daily_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenges
    ADD CONSTRAINT daily_challenges_pkey PRIMARY KEY (id);


--
-- Name: enhanced_lessons enhanced_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enhanced_lessons
    ADD CONSTRAINT enhanced_lessons_pkey PRIMARY KEY (id);


--
-- Name: exercise_submissions exercise_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_submissions
    ADD CONSTRAINT exercise_submissions_pkey PRIMARY KEY (id);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: languages languages_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_code_unique UNIQUE (code);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: learning_conversations learning_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_conversations
    ADD CONSTRAINT learning_conversations_pkey PRIMARY KEY (id);


--
-- Name: learning_profiles learning_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_profiles
    ADD CONSTRAINT learning_profiles_pkey PRIMARY KEY (id);


--
-- Name: lesson_completions lesson_completions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_completions
    ADD CONSTRAINT lesson_completions_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: pronunciation_analyses pronunciation_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pronunciation_analyses
    ADD CONSTRAINT pronunciation_analyses_pkey PRIMARY KEY (id);


--
-- Name: pronunciation_trends pronunciation_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pronunciation_trends
    ADD CONSTRAINT pronunciation_trends_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: stripe_checkout_fulfillments stripe_checkout_fulfillments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkout_fulfillments
    ADD CONSTRAINT stripe_checkout_fulfillments_pkey PRIMARY KEY (id);


--
-- Name: user_achievements user_achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_pkey PRIMARY KEY (id);


--
-- Name: user_languages user_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_languages
    ADD CONSTRAINT user_languages_pkey PRIMARY KEY (id);


--
-- Name: user_lessons user_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_lessons
    ADD CONSTRAINT user_lessons_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_unique UNIQUE (user_id);


--
-- Name: user_unit_legendary user_unit_legendary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_unit_legendary
    ADD CONSTRAINT user_unit_legendary_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: voice_sessions voice_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_sessions
    ADD CONSTRAINT voice_sessions_pkey PRIMARY KEY (id);


--
-- Name: xp_gains xp_gains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xp_gains
    ADD CONSTRAINT xp_gains_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: activity_summaries_profile_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX activity_summaries_profile_date_idx ON public.activity_summaries USING btree (profile_id, date, activity_type);


--
-- Name: ai_session_contexts_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_session_contexts_expires_at_idx ON public.ai_session_contexts USING btree (expires_at);


--
-- Name: ai_session_contexts_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_session_contexts_user_id_idx ON public.ai_session_contexts USING btree (user_id);


--
-- Name: ai_sessions_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_sessions_created_at_idx ON public.ai_learning_sessions USING btree (created_at);


--
-- Name: ai_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_sessions_user_id_idx ON public.ai_learning_sessions USING btree (user_id);


--
-- Name: conversations_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_session_id_idx ON public.learning_conversations USING btree (session_id);


--
-- Name: curricula_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX curricula_profile_id_idx ON public.curricula USING btree (profile_id);


--
-- Name: daily_challenges_user_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_challenges_user_date_idx ON public.daily_challenges USING btree (user_id, date);


--
-- Name: enhanced_lessons_curriculum_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enhanced_lessons_curriculum_id_idx ON public.enhanced_lessons USING btree (curriculum_id);


--
-- Name: enhanced_lessons_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enhanced_lessons_order_idx ON public.enhanced_lessons USING btree (curriculum_id, order_index);


--
-- Name: exercise_submissions_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exercise_submissions_profile_id_idx ON public.exercise_submissions USING btree (profile_id);


--
-- Name: exercise_submissions_profile_submitted_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exercise_submissions_profile_submitted_idx ON public.exercise_submissions USING btree (profile_id, submitted_at);


--
-- Name: exercise_submissions_submitted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exercise_submissions_submitted_at_idx ON public.exercise_submissions USING btree (submitted_at);


--
-- Name: lesson_completions_completed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lesson_completions_completed_at_idx ON public.lesson_completions USING btree (completed_at);


--
-- Name: lesson_completions_profile_completed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lesson_completions_profile_completed_idx ON public.lesson_completions USING btree (profile_id, completed_at);


--
-- Name: lesson_completions_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lesson_completions_profile_id_idx ON public.lesson_completions USING btree (profile_id);


--
-- Name: pronunciation_analyses_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pronunciation_analyses_profile_id_idx ON public.pronunciation_analyses USING btree (profile_id);


--
-- Name: pronunciation_analyses_profile_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pronunciation_analyses_profile_timestamp_idx ON public.pronunciation_analyses USING btree (profile_id, "timestamp");


--
-- Name: pronunciation_analyses_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pronunciation_analyses_timestamp_idx ON public.pronunciation_analyses USING btree ("timestamp");


--
-- Name: pronunciation_trends_profile_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pronunciation_trends_profile_date_idx ON public.pronunciation_trends USING btree (profile_id, date);


--
-- Name: stripe_checkout_fulfillments_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stripe_checkout_fulfillments_session_idx ON public.stripe_checkout_fulfillments USING btree (session_id);


--
-- Name: stripe_checkout_fulfillments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stripe_checkout_fulfillments_status_idx ON public.stripe_checkout_fulfillments USING btree (status);


--
-- Name: stripe_checkout_fulfillments_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stripe_checkout_fulfillments_user_idx ON public.stripe_checkout_fulfillments USING btree (user_id);


--
-- Name: user_achievements_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_achievements_user_id_idx ON public.user_achievements USING btree (user_id);


--
-- Name: user_language_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_language_idx ON public.user_languages USING btree (user_id, language_id);


--
-- Name: user_language_profile_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_language_profile_idx ON public.learning_profiles USING btree (user_id, target_language);


--
-- Name: user_lessons_completed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_lessons_completed_at_idx ON public.user_lessons USING btree (completed_at);


--
-- Name: user_lessons_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_lessons_user_id_idx ON public.user_lessons USING btree (user_id);


--
-- Name: user_unit_legendary_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_unit_legendary_user_idx ON public.user_unit_legendary USING btree (user_id);


--
-- Name: user_unit_legendary_user_unit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_unit_legendary_user_unit_idx ON public.user_unit_legendary USING btree (user_id, unit_id);


--
-- Name: users_last_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_active_idx ON public.users USING btree (last_active);


--
-- Name: users_xp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_xp_idx ON public.users USING btree (xp DESC NULLS LAST);


--
-- Name: users_xp_streak_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_xp_streak_idx ON public.users USING btree (xp DESC NULLS LAST, streak DESC NULLS LAST);


--
-- Name: voice_sessions_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_sessions_profile_id_idx ON public.voice_sessions USING btree (profile_id);


--
-- Name: voice_sessions_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_sessions_started_at_idx ON public.voice_sessions USING btree (started_at);


--
-- Name: xp_gains_user_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX xp_gains_user_timestamp_idx ON public.xp_gains USING btree (user_id, "timestamp");


--
-- Name: activity_summaries activity_summaries_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_summaries
    ADD CONSTRAINT activity_summaries_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: ai_learning_sessions ai_learning_sessions_language_id_languages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_learning_sessions
    ADD CONSTRAINT ai_learning_sessions_language_id_languages_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: ai_learning_sessions ai_learning_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_learning_sessions
    ADD CONSTRAINT ai_learning_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ai_session_contexts ai_session_contexts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_session_contexts
    ADD CONSTRAINT ai_session_contexts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: challenges challenges_language_id_languages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenges
    ADD CONSTRAINT challenges_language_id_languages_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: curricula curricula_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.curricula
    ADD CONSTRAINT curricula_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: daily_challenges daily_challenges_challenge_id_challenges_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenges
    ADD CONSTRAINT daily_challenges_challenge_id_challenges_id_fk FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: daily_challenges daily_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenges
    ADD CONSTRAINT daily_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: enhanced_lessons enhanced_lessons_curriculum_id_curricula_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enhanced_lessons
    ADD CONSTRAINT enhanced_lessons_curriculum_id_curricula_id_fk FOREIGN KEY (curriculum_id) REFERENCES public.curricula(id);


--
-- Name: exercise_submissions exercise_submissions_exercise_id_exercises_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_submissions
    ADD CONSTRAINT exercise_submissions_exercise_id_exercises_id_fk FOREIGN KEY (exercise_id) REFERENCES public.exercises(id);


--
-- Name: exercise_submissions exercise_submissions_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_submissions
    ADD CONSTRAINT exercise_submissions_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: learning_conversations learning_conversations_session_id_ai_learning_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_conversations
    ADD CONSTRAINT learning_conversations_session_id_ai_learning_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.ai_learning_sessions(id);


--
-- Name: learning_conversations learning_conversations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_conversations
    ADD CONSTRAINT learning_conversations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: learning_profiles learning_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_profiles
    ADD CONSTRAINT learning_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: lesson_completions lesson_completions_lesson_id_enhanced_lessons_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_completions
    ADD CONSTRAINT lesson_completions_lesson_id_enhanced_lessons_id_fk FOREIGN KEY (lesson_id) REFERENCES public.enhanced_lessons(id);


--
-- Name: lesson_completions lesson_completions_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_completions
    ADD CONSTRAINT lesson_completions_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: lessons lessons_language_id_languages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_language_id_languages_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: pronunciation_analyses pronunciation_analyses_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pronunciation_analyses
    ADD CONSTRAINT pronunciation_analyses_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: pronunciation_trends pronunciation_trends_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pronunciation_trends
    ADD CONSTRAINT pronunciation_trends_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: stripe_checkout_fulfillments stripe_checkout_fulfillments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkout_fulfillments
    ADD CONSTRAINT stripe_checkout_fulfillments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_achievements user_achievements_achievement_id_achievements_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_achievement_id_achievements_id_fk FOREIGN KEY (achievement_id) REFERENCES public.achievements(id);


--
-- Name: user_achievements user_achievements_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_languages user_languages_language_id_languages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_languages
    ADD CONSTRAINT user_languages_language_id_languages_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: user_languages user_languages_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_languages
    ADD CONSTRAINT user_languages_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_lessons user_lessons_lesson_id_lessons_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_lessons
    ADD CONSTRAINT user_lessons_lesson_id_lessons_id_fk FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- Name: user_lessons user_lessons_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_lessons
    ADD CONSTRAINT user_lessons_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_settings user_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_unit_legendary user_unit_legendary_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_unit_legendary
    ADD CONSTRAINT user_unit_legendary_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: voice_sessions voice_sessions_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_sessions
    ADD CONSTRAINT voice_sessions_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: xp_gains xp_gains_profile_id_learning_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xp_gains
    ADD CONSTRAINT xp_gains_profile_id_learning_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.learning_profiles(id);


--
-- Name: xp_gains xp_gains_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xp_gains
    ADD CONSTRAINT xp_gains_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict yX5Mb0W7ZGb9T4dJCy2rjZZvOGQOXkAITcTWFb9SCLN9H9i2AbuNcW8MT1s6A2i

