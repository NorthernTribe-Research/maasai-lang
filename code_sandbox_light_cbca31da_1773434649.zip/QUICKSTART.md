# Quick Start Guide

## 🚀 Getting Started with DuoLearn

### Instant Setup
1. Open `index.html` in any modern web browser
2. That's it! No installation or build process needed.

## 📖 How to Use

### First Time Users
1. **Choose Your Language**: Select from Spanish, French, German, Italian, or Japanese
2. **Start Learning**: Click the first green lesson circle to begin
3. **Complete Exercises**: Answer questions to progress through the lesson
4. **Track Progress**: Watch your XP, streak, and gems increase!

### Navigation Guide

#### Bottom Navigation Bar
- 🏠 **Learn** - Main learning path with all lessons
- 💪 **Practice** - Review mistakes and practice specific skills
- 🏆 **Leagues** - Compete with others on the leaderboard
- 🛒 **Shop** - Spend gems on helpful power-ups
- 👤 **Profile** - View your stats and achievements

### Exercise Types

#### Translation Exercises
- Read the question
- Select the correct answer from multiple choices
- Click "Check" to verify your answer

#### Listening Exercises
- Click the speaker icon to hear the audio
- Choose what you heard from the options
- Click "Check" to submit

#### Word Bank Exercises
- Tap words to build your answer
- Tap again to remove a word
- Click "Check" when complete

### Gamification Features

#### ❤️ Hearts (Health System)
- Start with 5 hearts
- Lose 1 heart per wrong answer
- Run out of hearts = lesson ends
- Refill by completing practice or buying in shop

#### 🔥 Streak
- Study every day to build your streak
- Higher streaks unlock achievements
- Buy Streak Freeze in shop for protection

#### ⭐ XP (Experience Points)
- Earn 10 XP per lesson (15 XP for perfect)
- Compete on leaderboards with XP
- Track total XP in your profile

#### 💎 Gems
- Earn 5 gems per completed lesson
- Spend in shop on power-ups
- No limit to how many you can earn!

### Shop Items

- **Streak Freeze** (10 gems) - Miss a day without breaking streak
- **Heart Refill** (5 gems) - Restore all hearts instantly
- **Timer Boost** (15 gems) - Extra time for challenges
- **XP Boost** (20 gems) - Double XP for 15 minutes

### Tips for Success

1. **Study Daily** - Even 5 minutes keeps your streak alive
2. **Practice Makes Perfect** - Use Practice Hub when stuck
3. **Save Your Gems** - Focus on Streak Freeze and Heart Refills
4. **Check Leaderboard** - See where you rank each week
5. **Unlock Achievements** - Complete milestones for badges

### Keyboard Shortcuts

- **Enter** - Submit answer / Continue
- **1-4** - Select option in multiple choice
- **Escape** - Exit lesson (with confirmation)

## 🎯 Learning Path Explained

### Lesson Node Colors

- 🟢 **Green** - Available to start now
- 🏆 **Gold** - Already completed
- ⚪ **Gray** - Locked (complete previous lesson first)
- 💜 **Purple** - Story lesson
- 🔵 **Blue** - Practice session

### Unit Structure

Each unit contains:
- 3-5 regular lessons
- 1 story (for reading practice)
- 1 practice session (for review)

Complete units in order to progress through the course.

## 💾 Data Persistence

Your progress is automatically saved to your browser's local storage:
- All XP, gems, hearts, and streaks
- Completed lessons
- Unlocked achievements
- Purchased items

**Note**: Clearing browser data will reset progress!

## 🐛 Troubleshooting

### Progress Not Saving?
- Ensure cookies/local storage is enabled in browser
- Don't use incognito/private mode

### Audio Not Working?
- Audio is simulated in this version
- Click the speaker button to "play" audio

### Lesson Won't Start?
- Ensure previous lesson is completed (gold)
- Refresh the page if stuck

## 🌟 Advanced Features

### Achievements to Unlock
- First Lesson - Complete your first lesson
- 3/7 Day Streak - Study consistently
- First Unit - Complete all lessons in a unit
- 100/500 XP - Reach XP milestones
- Perfect Lesson - No mistakes in a lesson
- Quick Learner - Complete lesson quickly

### League System
- Start in Bronze League
- Top performers advance to Silver, Gold, Diamond, Obsidian
- Reset weekly for fair competition

## 📱 Mobile Friendly

This app works great on:
- 📱 Smartphones (iOS, Android)
- 💻 Tablets
- 🖥️ Desktop computers

Responsive design adapts to your screen!

## 🔄 Reset Progress

To start over:
1. Open browser developer tools (F12)
2. Go to Application/Storage tab
3. Find Local Storage
4. Delete 'duolearn_progress' key
5. Refresh page

---

**Need Help?** Check the full README.md for detailed documentation.

**Ready to learn?** Open index.html and start your journey! 🚀
