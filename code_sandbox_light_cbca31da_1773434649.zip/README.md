# DuoLearn - Language Learning App

A fully functional Duolingo clone web application built with HTML, CSS, and JavaScript. Learn languages through interactive lessons, gamification, and engaging exercises.

![DuoLearn](https://img.shields.io/badge/Version-1.0.0-brightgreen) ![License](https://img.shields.io/badge/License-MIT-blue)

## 🎯 Project Overview

DuoLearn is a complete language learning platform inspired by Duolingo, featuring:
- **Interactive Learning Path** - Guided progression through structured units and lessons
- **Multiple Exercise Types** - Translation, listening, word bank exercises
- **Gamification System** - XP, streaks, hearts, gems, achievements
- **Social Features** - Leaderboards with weekly competitions
- **Practice Hub** - Targeted review for mistakes, listening, speaking, and vocabulary
- **Shop System** - Purchase power-ups and boosts with earned gems
- **Progress Tracking** - Comprehensive statistics and achievements

## ✨ Currently Completed Features

### 🏠 Home Screen (Learning Path)
- **Visual Learning Path** - Circular lesson nodes in a vertical path layout
- **Unit Organization** - Lessons grouped into themed units
- **Progress Tracking** - Visual indicators for completed, available, and locked lessons
- **Multiple Lesson Types**:
  - 🗣️ Regular lessons
  - 📖 Stories (special reading exercises)
  - 💪 Practice sessions
- **Language Switcher** - Support for Spanish, French, German, Italian, Japanese
- **Smart Progression** - Unlock system based on completion

### 📚 Lesson System
- **Multiple Exercise Types**:
  - **Translation** - Multiple choice translation exercises
  - **Listening** - Audio comprehension with playback
  - **Word Bank** - Sentence construction from word chips
- **Real-time Feedback** - Immediate correct/incorrect indication
- **Progress Bar** - Visual lesson completion tracking
- **Heart System** - Limited mistakes before lesson failure
- **Lesson Completion** - XP and gem rewards with accuracy tracking

### 🎮 Gamification Features
- **XP System** - Earn experience points for completing lessons
- **Streak Counter** - Track consecutive days of learning
- **Hearts** - Health system limiting mistakes (5 hearts max)
- **Gems** - In-app currency earned through lessons
- **Achievements** - Unlock badges for milestones:
  - First Lesson
  - 3 Day Streak
  - 7 Day Streak
  - First Unit Complete
  - 100 XP / 500 XP milestones
  - Perfect Lesson
  - Quick Learner

### 🏆 Leaderboard
- **Weekly Competition** - Compete with other learners
- **League System** - Bronze, Silver, Gold, Diamond, Obsidian leagues
- **XP Ranking** - See top performers and your position
- **Streak Display** - View other learners' dedication
- **Real-time Updates** - Your progress reflected immediately

### 💪 Practice Hub
- **Review Mistakes** - Retry exercises you got wrong
- **Listening Practice** - Focus on comprehension skills
- **Speaking Practice** - Pronunciation and speaking exercises
- **Vocabulary Review** - Match words and meanings
- **Targeted Learning** - Focus on specific skill areas

### 🛒 Shop
- **Streak Freeze** (10 gems) - Protect your streak for one day
- **Heart Refill** (5 gems) - Restore all hearts instantly
- **Timer Boost** (15 gems) - Extra time for timed challenges
- **XP Boost** (20 gems) - 2x XP for 15 minutes
- **Real Purchases** - Spend earned gems on power-ups

### 👤 Profile
- **Statistics Dashboard**:
  - Total XP earned
  - Current streak
  - Lessons completed
  - Time spent learning
  - Current league
- **Achievements Gallery** - View all unlocked badges
- **Progress Overview** - Comprehensive learning statistics

### 💾 Data Persistence
- **Local Storage** - Progress saved automatically
- **RESTful Table API Integration** - Ready for server-side persistence
- **Three Database Tables**:
  - `user_progress` - User stats, XP, streaks, completed lessons
  - `lesson_stats` - Individual lesson completion data
  - `leaderboard` - Competitive rankings

## 🚀 Functional Entry Points

### Main Application URLs
- `/` or `/index.html` - **Home Screen (Learning Path)**
  - Primary entry point for learning
  - Visual lesson progression
  - Language selection

### Navigation Screens (Bottom Nav)
- **Learn Tab** (Home) - Main learning path interface
- **Practice Tab** - Access practice hub with 4 practice types
- **Leagues Tab** - View leaderboard and rankings
- **Shop Tab** - Purchase items with gems
- **Profile Tab** - View statistics and achievements

### User Actions
- **Start Lesson** - Click available lesson node on path
- **Complete Exercise** - Answer questions and get feedback
- **Purchase Items** - Click buy buttons in shop (requires gems)
- **Switch Language** - Use dropdown at top of learning path
- **Track Progress** - View hearts, XP, gems, streak in header

## 📊 Data Models

### User Progress
```javascript
{
  xp: Number,              // Total experience points
  hearts: Number,          // Current hearts (0-5)
  maxHearts: Number,       // Maximum hearts (5)
  gems: Number,            // In-app currency
  streak: Number,          // Consecutive days
  lastStudyDate: String,   // ISO date string
  completedLessons: Array, // Lesson IDs completed
  lessonsCompleted: Number,// Total count
  timeSpent: Number,       // Hours studied
  achievements: Array,     // Unlocked achievement IDs
  inventory: Array         // Purchased items
}
```

### Lesson Structure
```javascript
{
  id: Number,              // Unique lesson ID
  type: String,            // 'lesson', 'story', 'practice'
  icon: String,            // Emoji icon
  status: String           // 'locked', 'available', 'completed'
}
```

### Exercise Types
```javascript
// Translation Exercise
{
  type: "translate",
  question: String,
  options: Array,
  correct: Number,         // Index of correct answer
  translation: String
}

// Listening Exercise
{
  type: "listening",
  question: String,
  audio: String,           // Audio content/URL
  options: Array,
  correct: Number
}

// Word Bank Exercise
{
  type: "wordbank",
  question: String,
  words: Array,            // Available words
  correct: Array           // Correct word sequence
}
```

## 🔧 Technical Architecture

### Technology Stack
- **HTML5** - Semantic markup structure
- **CSS3** - Modern styling with CSS Grid/Flexbox
- **JavaScript (ES6+)** - Object-oriented application logic
- **Font Awesome** - Icon library
- **Google Fonts** - Inter font family

### File Structure
```
duolearn/
├── index.html           # Main application HTML
├── css/
│   └── style.css        # Complete styling (18KB+)
├── js/
│   ├── data.js          # Course data and templates
│   ├── exercises.js     # Exercise rendering logic
│   └── app.js           # Main application controller
└── README.md            # Documentation
```

### Key Classes
- **DuoLearnApp** - Main application controller
- **ExerciseRenderer** - Handles exercise display and interaction
- **PracticeGenerator** - Generates practice exercises

## 🎨 Design System

### Color Palette
- **Primary Green**: `#58cc02` - Main action color
- **Secondary Blue**: `#1cb0f6` - Interactive elements
- **Danger Red**: `#ff4b4b` - Errors and hearts
- **Warning Yellow**: `#ffc800` - Achievements and leagues
- **Background**: `#ffffff` / `#f7f7f7`
- **Text**: `#3c3c3c` / `#777777`

### Typography
- **Font Family**: Inter (300, 400, 500, 600, 700, 800 weights)
- **Responsive Sizing**: Adapts to screen size

## 📱 Responsive Design
- **Mobile-first** approach
- **Breakpoint**: 768px for tablets and desktop
- **Touch-friendly** - Large buttons and interactive areas
- **Bottom navigation** - Easy thumb access on mobile

## 🔮 Features Not Yet Implemented

### High Priority
- [ ] Audio playback for listening exercises (currently simulated)
- [ ] Text-to-speech for pronunciation
- [ ] More lesson content for all languages (currently Spanish has most content)
- [ ] Story mode with dialogues
- [ ] Character voices and animations
- [ ] Microphone integration for speaking exercises

### Medium Priority
- [ ] Friends system and social features
- [ ] Friends Quests (collaborative challenges)
- [ ] Push notifications for streak reminders
- [ ] Offline mode support
- [ ] Discussion forums per lesson
- [ ] Tips and notes in guidebooks
- [ ] Legendary level challenges

### Low Priority
- [ ] Dark mode theme
- [ ] Customizable avatars
- [ ] More achievement types
- [ ] Season pass / Super DuoLearn subscription
- [ ] Duolingo Max AI features
- [ ] Multiple device sync
- [ ] Email reports

## 🚀 Recommended Next Steps

### Phase 1: Content Enhancement
1. Add more exercise content for Spanish (Units 2-4)
2. Expand French, German, Italian, Japanese courses
3. Create story content with dialogues
4. Add tips/grammar explanations for each unit

### Phase 2: Audio Integration
1. Integrate text-to-speech API for pronunciations
2. Add real audio files for listening exercises
3. Implement microphone access for speaking practice
4. Add voice recognition for pronunciation scoring

### Phase 3: Social Features
1. Implement friends system (add, remove, search)
2. Create Friends Quest system
3. Add messaging between friends
4. Implement friend activity feed

### Phase 4: Advanced Features
1. Add AI-powered explanations (like Duolingo Max)
2. Create video call roleplay feature
3. Implement adaptive learning algorithms
4. Add personalized lesson recommendations

### Phase 5: Backend Integration
1. Replace localStorage with RESTful API calls
2. Implement user authentication system
3. Add cloud sync across devices
4. Create admin dashboard for content management

## 🛠️ Setup & Installation

1. **Clone or download** this project
2. **Open** `index.html` in a modern web browser
3. **Start learning** - No build process required!

### For Development
- Use Live Server extension in VS Code for hot reload
- Browser DevTools for debugging
- localStorage inspector to view saved progress

## 🧪 Testing Checklist

- [x] Lesson completion flow
- [x] XP and gem earning
- [x] Streak tracking
- [x] Heart system
- [x] Shop purchases
- [x] Progress persistence
- [x] Achievement unlocking
- [x] Leaderboard updates
- [x] Responsive design
- [x] Exercise feedback

## 📝 Usage Tips

1. **Complete lessons daily** to build your streak
2. **Use hearts wisely** - wrong answers cost hearts
3. **Earn gems** by completing lessons and use them in the shop
4. **Try practice hub** when you're low on hearts
5. **Check leaderboard** to see your weekly ranking
6. **View profile** to track overall progress

## 🤝 Contributing

This is a demonstration project. To extend it:
1. Add more exercises in `js/data.js`
2. Create new exercise types in `js/exercises.js`
3. Extend UI in `index.html` and `css/style.css`
4. Add features in `js/app.js`

## 📄 License

MIT License - Free to use and modify

## 🙏 Acknowledgments

Inspired by Duolingo's excellent UX design and gamification approach. This is an educational clone created for learning purposes.

---

**Built with ❤️ for language learners everywhere**

*Last Updated: 2026-03-13*
