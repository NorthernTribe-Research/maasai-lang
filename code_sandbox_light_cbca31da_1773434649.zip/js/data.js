// Course Data Structure
const courseData = {
    spanish: {
        name: "Spanish",
        units: [
            {
                id: 1,
                title: "Unit 1: Greetings & Basics",
                lessons: [
                    { id: 1, type: "lesson", icon: "🗣️", status: "available" },
                    { id: 2, type: "lesson", icon: "📝", status: "locked" },
                    { id: 3, type: "lesson", icon: "🎧", status: "locked" },
                    { id: 4, type: "story", icon: "📖", status: "locked" },
                    { id: 5, type: "practice", icon: "💪", status: "locked" }
                ]
            },
            {
                id: 2,
                title: "Unit 2: Food & Drinks",
                lessons: [
                    { id: 6, type: "lesson", icon: "🍎", status: "locked" },
                    { id: 7, type: "lesson", icon: "☕", status: "locked" },
                    { id: 8, type: "lesson", icon: "🍽️", status: "locked" },
                    { id: 9, type: "story", icon: "📖", status: "locked" },
                    { id: 10, type: "practice", icon: "💪", status: "locked" }
                ]
            },
            {
                id: 3,
                title: "Unit 3: Family & People",
                lessons: [
                    { id: 11, type: "lesson", icon: "👨‍👩‍👧", status: "locked" },
                    { id: 12, type: "lesson", icon: "👥", status: "locked" },
                    { id: 13, type: "lesson", icon: "❤️", status: "locked" },
                    { id: 14, type: "story", icon: "📖", status: "locked" },
                    { id: 15, type: "practice", icon: "💪", status: "locked" }
                ]
            },
            {
                id: 4,
                title: "Unit 4: Travel & Places",
                lessons: [
                    { id: 16, type: "lesson", icon: "✈️", status: "locked" },
                    { id: 17, type: "lesson", icon: "🗺️", status: "locked" },
                    { id: 18, type: "lesson", icon: "🏨", status: "locked" },
                    { id: 19, type: "story", icon: "📖", status: "locked" },
                    { id: 20, type: "practice", icon: "💪", status: "locked" }
                ]
            }
        ]
    },
    french: {
        name: "French",
        units: [
            {
                id: 1,
                title: "Unit 1: Bonjour!",
                lessons: [
                    { id: 1, type: "lesson", icon: "🗣️", status: "available" },
                    { id: 2, type: "lesson", icon: "📝", status: "locked" },
                    { id: 3, type: "story", icon: "📖", status: "locked" }
                ]
            }
        ]
    },
    german: {
        name: "German",
        units: [
            {
                id: 1,
                title: "Unit 1: Guten Tag!",
                lessons: [
                    { id: 1, type: "lesson", icon: "🗣️", status: "available" },
                    { id: 2, type: "lesson", icon: "📝", status: "locked" },
                    { id: 3, type: "story", icon: "📖", status: "locked" }
                ]
            }
        ]
    },
    italian: {
        name: "Italian",
        units: [
            {
                id: 1,
                title: "Unit 1: Ciao!",
                lessons: [
                    { id: 1, type: "lesson", icon: "🗣️", status: "available" },
                    { id: 2, type: "lesson", icon: "📝", status: "locked" },
                    { id: 3, type: "story", icon: "📖", status: "locked" }
                ]
            }
        ]
    },
    japanese: {
        name: "Japanese",
        units: [
            {
                id: 1,
                title: "Unit 1: Konnichiwa!",
                lessons: [
                    { id: 1, type: "lesson", icon: "🗣️", status: "available" },
                    { id: 2, type: "lesson", icon: "📝", status: "locked" },
                    { id: 3, type: "story", icon: "📖", status: "locked" }
                ]
            }
        ]
    }
};

// Exercise Templates
const exerciseTemplates = {
    spanish: {
        1: [
            {
                type: "translate",
                question: "How do you say 'Hello' in Spanish?",
                options: ["Hola", "Adiós", "Gracias", "Por favor"],
                correct: 0,
                translation: "Hello"
            },
            {
                type: "translate",
                question: "What does 'Buenos días' mean?",
                options: ["Good night", "Good morning", "Good afternoon", "Goodbye"],
                correct: 1,
                translation: "Good morning"
            },
            {
                type: "listening",
                question: "What do you hear?",
                audio: "Hola, ¿cómo estás?",
                options: ["Hello, how are you?", "Goodbye, see you later", "Thank you very much", "Please help me"],
                correct: 0
            },
            {
                type: "wordbank",
                question: "Translate: 'Nice to meet you'",
                words: ["Mucho", "gusto", "en", "conocerte"],
                correct: ["Mucho", "gusto"]
            },
            {
                type: "translate",
                question: "What does 'Gracias' mean?",
                options: ["Please", "Thank you", "Sorry", "Excuse me"],
                correct: 1,
                translation: "Thank you"
            },
            {
                type: "translate",
                question: "How do you say 'Goodbye' in Spanish?",
                options: ["Hola", "Adiós", "Sí", "No"],
                correct: 1,
                translation: "Goodbye"
            },
            {
                type: "wordbank",
                question: "Translate: 'My name is'",
                words: ["Me", "llamo", "es", "nombre", "mi"],
                correct: ["Me", "llamo"]
            },
            {
                type: "translate",
                question: "What does '¿Cómo estás?' mean?",
                options: ["What is your name?", "How are you?", "Where are you?", "What time is it?"],
                correct: 1,
                translation: "How are you?"
            },
            {
                type: "listening",
                question: "What do you hear?",
                audio: "Mucho gusto",
                options: ["Nice to meet you", "See you later", "Good morning", "You're welcome"],
                correct: 0
            },
            {
                type: "translate",
                question: "How do you say 'Please' in Spanish?",
                options: ["Gracias", "Por favor", "Perdón", "De nada"],
                correct: 1,
                translation: "Please"
            }
        ],
        6: [
            {
                type: "translate",
                question: "What does 'Manzana' mean?",
                options: ["Banana", "Apple", "Orange", "Grape"],
                correct: 1,
                translation: "Apple"
            },
            {
                type: "translate",
                question: "How do you say 'Water' in Spanish?",
                options: ["Leche", "Café", "Agua", "Jugo"],
                correct: 2,
                translation: "Water"
            },
            {
                type: "wordbank",
                question: "Translate: 'I like coffee'",
                words: ["Me", "gusta", "el", "café", "agua"],
                correct: ["Me", "gusta", "el", "café"]
            }
        ]
    }
};

// Leaderboard Data
const leaderboardData = [
    { name: "You", xp: 0, streak: 0, avatar: "🙂" },
    { name: "Maria", xp: 2450, streak: 45, avatar: "👩" },
    { name: "Carlos", xp: 2380, streak: 32, avatar: "👨" },
    { name: "Sophie", xp: 2210, streak: 28, avatar: "👱‍♀️" },
    { name: "João", xp: 2150, streak: 41, avatar: "👨‍🦱" },
    { name: "Emma", xp: 2080, streak: 25, avatar: "👩‍🦰" },
    { name: "Luis", xp: 1950, streak: 19, avatar: "👨‍🦲" },
    { name: "Yuki", xp: 1820, streak: 22, avatar: "👩‍🦳" },
    { name: "Ahmed", xp: 1750, streak: 15, avatar: "🧔" },
    { name: "Isabella", xp: 1680, streak: 18, avatar: "👩‍🦱" }
];

// Achievements Data
const achievementsData = [
    { id: 1, name: "First Lesson", icon: "🎯", unlocked: false },
    { id: 2, name: "3 Day Streak", icon: "🔥", unlocked: false },
    { id: 3, name: "7 Day Streak", icon: "🔥🔥", unlocked: false },
    { id: 4, name: "First Unit", icon: "📚", unlocked: false },
    { id: 5, name: "100 XP", icon: "⭐", unlocked: false },
    { id: 6, name: "500 XP", icon: "⭐⭐", unlocked: false },
    { id: 7, name: "Perfect Lesson", icon: "💯", unlocked: false },
    { id: 8, name: "Quick Learner", icon: "⚡", unlocked: false }
];

// Shop Items
const shopItems = [
    {
        id: "streak-freeze",
        name: "Streak Freeze",
        description: "Protect your streak for one day",
        cost: 10,
        icon: "❄️"
    },
    {
        id: "heart-refill",
        name: "Heart Refill",
        description: "Restore your hearts to full",
        cost: 5,
        icon: "❤️"
    },
    {
        id: "timer-boost",
        name: "Timer Boost",
        description: "Get more time in timed challenges",
        cost: 15,
        icon: "⚡"
    },
    {
        id: "xp-boost",
        name: "XP Boost",
        description: "Earn 2x XP for 15 minutes",
        cost: 20,
        icon: "🌟"
    }
];
