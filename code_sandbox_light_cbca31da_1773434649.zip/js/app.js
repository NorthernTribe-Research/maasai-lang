// Main Application Controller
class DuoLearnApp {
    constructor() {
        this.currentLanguage = 'spanish';
        this.userProgress = {
            xp: 0,
            hearts: 5,
            maxHearts: 5,
            gems: 500,
            streak: 0,
            lastStudyDate: null,
            completedLessons: [],
            lessonsCompleted: 0,
            timeSpent: 0,
            achievements: [],
            inventory: []
        };
        this.currentLesson = null;
        this.currentExercises = [];
        this.currentExerciseIndex = 0;
        this.lessonCorrect = 0;
        this.lessonTotal = 0;
        this.exerciseRenderer = new ExerciseRenderer(document.getElementById('lessonContent'));
        
        this.init();
    }

    init() {
        this.loadProgress();
        this.setupNavigation();
        this.renderLearningPath();
        this.updateUI();
        this.setupShop();
        this.updateLeaderboard();
        this.renderAchievements();
        this.checkStreak();
    }

    loadProgress() {
        const saved = localStorage.getItem('duolearn_progress');
        if (saved) {
            this.userProgress = { ...this.userProgress, ...JSON.parse(saved) };
        }
    }

    saveProgress() {
        localStorage.setItem('duolearn_progress', JSON.stringify(this.userProgress));
    }

    checkStreak() {
        const today = new Date().toDateString();
        const lastStudy = this.userProgress.lastStudyDate;
        
        if (lastStudy) {
            const lastDate = new Date(lastStudy);
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            if (lastDate.toDateString() === yesterday.toDateString()) {
                // Streak continues if they studied yesterday
            } else if (lastDate.toDateString() !== today) {
                // Streak broken
                this.userProgress.streak = 0;
            }
        }
    }

    updateStreak() {
        const today = new Date().toDateString();
        if (this.userProgress.lastStudyDate !== today) {
            this.userProgress.streak++;
            this.userProgress.lastStudyDate = today;
            this.checkAchievements();
            this.saveProgress();
            this.updateUI();
        }
    }

    setupNavigation() {
        const navButtons = document.querySelectorAll('.nav-btn');
        navButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const screenName = btn.dataset.screen;
                this.showScreen(screenName);
                
                navButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });

        // Language selector
        document.getElementById('languageSelect').addEventListener('change', (e) => {
            this.currentLanguage = e.target.value;
            this.renderLearningPath();
        });

        // Close lesson button
        document.getElementById('closeLessonBtn').addEventListener('click', () => {
            if (confirm('Are you sure you want to exit this lesson?')) {
                this.showScreen('home');
            }
        });

        // Completion modal continue button
        document.getElementById('continueBtn').addEventListener('click', () => {
            document.getElementById('completionModal').classList.remove('show');
            this.showScreen('home');
        });

        // Practice cards
        document.querySelectorAll('.practice-card').forEach(card => {
            card.addEventListener('click', () => {
                const practiceType = card.dataset.practice;
                this.startPractice(practiceType);
            });
        });
    }

    showScreen(screenName) {
        const screens = document.querySelectorAll('.screen');
        screens.forEach(screen => screen.classList.remove('active'));
        
        const screenMap = {
            'home': 'homeScreen',
            'practice': 'practiceScreen',
            'leaderboard': 'leaderboardScreen',
            'shop': 'shopScreen',
            'profile': 'profileScreen',
            'lesson': 'lessonScreen'
        };
        
        const targetScreen = document.getElementById(screenMap[screenName]);
        if (targetScreen) {
            targetScreen.classList.add('active');
            
            if (screenName === 'leaderboard') {
                this.updateLeaderboard();
            } else if (screenName === 'profile') {
                this.updateProfile();
            }
        }
    }

    renderLearningPath() {
        const pathContainer = document.getElementById('learningPath');
        const course = courseData[this.currentLanguage];
        
        if (!course) {
            pathContainer.innerHTML = '<p>Course not available yet!</p>';
            return;
        }

        pathContainer.innerHTML = course.units.map(unit => {
            const completedLessons = unit.lessons.filter(lesson => 
                this.userProgress.completedLessons.includes(`${this.currentLanguage}-${lesson.id}`)
            ).length;
            
            return `
                <div class="unit">
                    <div class="unit-header">
                        <div class="unit-title">${unit.title}</div>
                        <div class="unit-progress">${completedLessons}/${unit.lessons.length}</div>
                    </div>
                    <div class="lessons-grid">
                        ${unit.lessons.map((lesson, index) => {
                            const isCompleted = this.userProgress.completedLessons.includes(`${this.currentLanguage}-${lesson.id}`);
                            const prevCompleted = index === 0 || 
                                this.userProgress.completedLessons.includes(`${this.currentLanguage}-${unit.lessons[index - 1].id}`);
                            
                            let status = 'locked';
                            if (isCompleted) status = 'completed';
                            else if (prevCompleted) status = 'available';
                            
                            return `
                                <div class="lesson-node ${lesson.type} ${status}" 
                                     data-lesson-id="${lesson.id}"
                                     data-unit-id="${unit.id}">
                                    <div class="lesson-icon">${lesson.icon}</div>
                                    <div class="lesson-number">${lesson.id}</div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        }).join('');

        // Add click handlers to lesson nodes
        document.querySelectorAll('.lesson-node').forEach(node => {
            if (node.classList.contains('available') || node.classList.contains('completed')) {
                node.addEventListener('click', () => {
                    const lessonId = parseInt(node.dataset.lessonId);
                    this.startLesson(lessonId);
                });
            }
        });
    }

    startLesson(lessonId) {
        this.currentLesson = lessonId;
        
        // Get exercises for this lesson
        const exercises = exerciseTemplates[this.currentLanguage]?.[lessonId];
        
        if (!exercises || exercises.length === 0) {
            alert('This lesson is not available yet!');
            return;
        }

        this.currentExercises = [...exercises];
        this.currentExerciseIndex = 0;
        this.lessonCorrect = 0;
        this.lessonTotal = exercises.length;
        
        // Reset hearts for the lesson
        document.getElementById('lessonHearts').textContent = this.userProgress.hearts;
        
        this.showScreen('lesson');
        this.renderCurrentExercise();
        this.updateLessonProgress();
    }

    renderCurrentExercise() {
        if (this.currentExerciseIndex >= this.currentExercises.length) {
            this.completeLesson();
            return;
        }

        const exercise = this.currentExercises[this.currentExerciseIndex];
        
        this.exerciseRenderer.onAnswer = (isCorrect) => {
            if (isCorrect) {
                this.lessonCorrect++;
            } else {
                this.userProgress.hearts--;
                document.getElementById('lessonHearts').textContent = this.userProgress.hearts;
                document.getElementById('heartsCount').textContent = this.userProgress.hearts;
                
                if (this.userProgress.hearts <= 0) {
                    alert('You ran out of hearts! Complete a practice lesson to earn more.');
                    this.userProgress.hearts = this.userProgress.maxHearts;
                    this.showScreen('home');
                    return;
                }
            }
            
            this.currentExerciseIndex++;
            this.updateLessonProgress();
            
            setTimeout(() => {
                this.renderCurrentExercise();
            }, 300);
        };

        switch (exercise.type) {
            case 'translate':
                this.exerciseRenderer.renderTranslateExercise(exercise);
                break;
            case 'listening':
                this.exerciseRenderer.renderListeningExercise(exercise);
                break;
            case 'wordbank':
                this.exerciseRenderer.renderWordBankExercise(exercise);
                break;
        }
    }

    updateLessonProgress() {
        const progress = (this.currentExerciseIndex / this.lessonTotal) * 100;
        document.getElementById('lessonProgress').style.width = progress + '%';
    }

    completeLesson() {
        const lessonKey = `${this.currentLanguage}-${this.currentLesson}`;
        
        if (!this.userProgress.completedLessons.includes(lessonKey)) {
            this.userProgress.completedLessons.push(lessonKey);
            this.userProgress.lessonsCompleted++;
        }

        const xpEarned = 10 + (this.lessonCorrect === this.lessonTotal ? 5 : 0);
        this.userProgress.xp += xpEarned;
        this.userProgress.gems += 5;
        
        this.updateStreak();
        this.checkAchievements();
        this.saveProgress();
        this.updateUI();
        this.renderLearningPath();

        // Show completion modal
        const accuracy = Math.round((this.lessonCorrect / this.lessonTotal) * 100);
        document.getElementById('xpEarned').textContent = `+${xpEarned}`;
        document.getElementById('accuracy').textContent = `${accuracy}%`;
        document.getElementById('completionModal').classList.add('show');
    }

    startPractice(practiceType) {
        let exercises = [];
        
        switch (practiceType) {
            case 'mistakes':
                exercises = PracticeGenerator.generateMistakeReview();
                break;
            case 'listening':
                exercises = PracticeGenerator.generateListeningPractice();
                break;
            case 'speaking':
                exercises = PracticeGenerator.generateSpeakingPractice();
                break;
            case 'vocabulary':
                exercises = PracticeGenerator.generateVocabularyReview();
                break;
        }

        if (exercises.length === 0) {
            alert('No practice exercises available yet!');
            return;
        }

        this.currentLesson = 'practice';
        this.currentExercises = exercises;
        this.currentExerciseIndex = 0;
        this.lessonCorrect = 0;
        this.lessonTotal = exercises.length;
        
        this.showScreen('lesson');
        this.renderCurrentExercise();
        this.updateLessonProgress();
    }

    updateUI() {
        document.getElementById('streakCount').textContent = this.userProgress.streak;
        document.getElementById('heartsCount').textContent = this.userProgress.hearts;
        document.getElementById('gemsCount').textContent = this.userProgress.gems;
        document.getElementById('shopGems').textContent = this.userProgress.gems;
    }

    updateLeaderboard() {
        const leaderboard = [...leaderboardData];
        leaderboard[0].xp = this.userProgress.xp;
        leaderboard[0].streak = this.userProgress.streak;
        
        leaderboard.sort((a, b) => b.xp - a.xp);
        
        const listHtml = leaderboard.map((user, index) => `
            <div class="leaderboard-item ${index < 3 ? 'top-3' : ''}">
                <div class="leaderboard-rank">${index + 1}</div>
                <div class="leaderboard-avatar">${user.avatar}</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">${user.name}</div>
                    <div class="leaderboard-streak">${user.streak} day streak</div>
                </div>
                <div class="leaderboard-xp">${user.xp} XP</div>
            </div>
        `).join('');
        
        document.getElementById('leaderboardList').innerHTML = listHtml;
    }

    updateProfile() {
        document.getElementById('totalXP').textContent = this.userProgress.xp;
        document.getElementById('profileStreak').textContent = this.userProgress.streak;
        document.getElementById('lessonsCompleted').textContent = this.userProgress.lessonsCompleted;
        document.getElementById('timeSpent').textContent = 
            Math.floor(this.userProgress.lessonsCompleted * 0.5) + 'h';
    }

    renderAchievements() {
        const html = achievementsData.map(achievement => {
            const unlocked = this.userProgress.achievements.includes(achievement.id);
            return `
                <div class="achievement ${unlocked ? 'unlocked' : ''}">
                    <div class="achievement-icon">${achievement.icon}</div>
                    <div class="achievement-name">${achievement.name}</div>
                </div>
            `;
        }).join('');
        
        document.getElementById('achievementsGrid').innerHTML = html;
    }

    checkAchievements() {
        const achievements = [];
        
        if (this.userProgress.lessonsCompleted >= 1 && !this.userProgress.achievements.includes(1)) {
            achievements.push(1);
        }
        if (this.userProgress.streak >= 3 && !this.userProgress.achievements.includes(2)) {
            achievements.push(2);
        }
        if (this.userProgress.streak >= 7 && !this.userProgress.achievements.includes(3)) {
            achievements.push(3);
        }
        if (this.userProgress.lessonsCompleted >= 5 && !this.userProgress.achievements.includes(4)) {
            achievements.push(4);
        }
        if (this.userProgress.xp >= 100 && !this.userProgress.achievements.includes(5)) {
            achievements.push(5);
        }
        if (this.userProgress.xp >= 500 && !this.userProgress.achievements.includes(6)) {
            achievements.push(6);
        }
        
        achievements.forEach(id => {
            if (!this.userProgress.achievements.includes(id)) {
                this.userProgress.achievements.push(id);
            }
        });
        
        this.renderAchievements();
    }

    setupShop() {
        document.querySelectorAll('.shop-item').forEach(item => {
            const buyBtn = item.querySelector('.buy-btn');
            buyBtn.addEventListener('click', () => {
                const itemId = item.dataset.item;
                const cost = parseInt(item.dataset.cost);
                
                if (this.userProgress.gems >= cost) {
                    this.purchaseItem(itemId, cost);
                } else {
                    alert('Not enough gems!');
                }
            });
        });
    }

    purchaseItem(itemId, cost) {
        this.userProgress.gems -= cost;
        
        switch (itemId) {
            case 'streak-freeze':
                this.userProgress.inventory.push('streak-freeze');
                alert('Streak Freeze purchased! Your streak is protected for today.');
                break;
            case 'heart-refill':
                this.userProgress.hearts = this.userProgress.maxHearts;
                alert('Hearts refilled!');
                break;
            case 'timer-boost':
                this.userProgress.inventory.push('timer-boost');
                alert('Timer Boost activated!');
                break;
            case 'xp-boost':
                this.userProgress.inventory.push('xp-boost');
                alert('XP Boost activated for 15 minutes!');
                break;
        }
        
        this.saveProgress();
        this.updateUI();
    }
}

// Initialize the app when the page loads
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new DuoLearnApp();
});
