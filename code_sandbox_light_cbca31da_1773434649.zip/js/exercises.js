// Exercise Rendering and Logic
class ExerciseRenderer {
    constructor(container) {
        this.container = container;
        this.currentAnswer = null;
    }

    renderTranslateExercise(exercise) {
        const html = `
            <div class="exercise">
                <div class="exercise-type">Translation</div>
                <div class="exercise-question">${exercise.question}</div>
                <div class="exercise-options">
                    ${exercise.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
                <button class="check-btn" disabled>Check</button>
                <div class="feedback"></div>
            </div>
        `;
        
        this.container.innerHTML = html;
        this.setupTranslateListeners(exercise);
    }

    setupTranslateListeners(exercise) {
        const options = this.container.querySelectorAll('.option-btn');
        const checkBtn = this.container.querySelector('.check-btn');
        const feedback = this.container.querySelector('.feedback');
        
        options.forEach(option => {
            option.addEventListener('click', () => {
                options.forEach(opt => opt.classList.remove('selected'));
                option.classList.add('selected');
                this.currentAnswer = parseInt(option.dataset.index);
                checkBtn.disabled = false;
            });
        });

        checkBtn.addEventListener('click', () => {
            const isCorrect = this.currentAnswer === exercise.correct;
            
            options.forEach((option, index) => {
                if (index === exercise.correct) {
                    option.classList.add('correct');
                } else if (index === this.currentAnswer && !isCorrect) {
                    option.classList.add('incorrect');
                }
            });

            feedback.textContent = isCorrect ? 
                '✓ Excellent!' : 
                `✗ Correct answer: ${exercise.options[exercise.correct]}`;
            feedback.className = `feedback show ${isCorrect ? 'correct' : 'incorrect'}`;
            
            checkBtn.textContent = 'Continue';
            checkBtn.disabled = false;
            
            checkBtn.onclick = () => {
                this.onAnswer(isCorrect);
            };
        });
    }

    renderListeningExercise(exercise) {
        const html = `
            <div class="exercise">
                <div class="exercise-type">Listening</div>
                <div class="exercise-question">${exercise.question}</div>
                <div class="exercise-audio">
                    <button class="audio-btn">
                        <i class="fas fa-volume-up"></i>
                    </button>
                </div>
                <div class="exercise-options">
                    ${exercise.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
                <button class="check-btn" disabled>Check</button>
                <div class="feedback"></div>
            </div>
        `;
        
        this.container.innerHTML = html;
        this.setupListeningListeners(exercise);
    }

    setupListeningListeners(exercise) {
        const audioBtn = this.container.querySelector('.audio-btn');
        const options = this.container.querySelectorAll('.option-btn');
        const checkBtn = this.container.querySelector('.check-btn');
        const feedback = this.container.querySelector('.feedback');
        
        // Simulate audio playback
        audioBtn.addEventListener('click', () => {
            audioBtn.style.transform = 'scale(0.9)';
            setTimeout(() => {
                audioBtn.style.transform = 'scale(1)';
            }, 200);
            
            // In a real app, this would play actual audio
            console.log('Playing audio:', exercise.audio);
        });

        options.forEach(option => {
            option.addEventListener('click', () => {
                options.forEach(opt => opt.classList.remove('selected'));
                option.classList.add('selected');
                this.currentAnswer = parseInt(option.dataset.index);
                checkBtn.disabled = false;
            });
        });

        checkBtn.addEventListener('click', () => {
            const isCorrect = this.currentAnswer === exercise.correct;
            
            options.forEach((option, index) => {
                if (index === exercise.correct) {
                    option.classList.add('correct');
                } else if (index === this.currentAnswer && !isCorrect) {
                    option.classList.add('incorrect');
                }
            });

            feedback.textContent = isCorrect ? 
                '✓ Great listening!' : 
                `✗ Correct answer: ${exercise.options[exercise.correct]}`;
            feedback.className = `feedback show ${isCorrect ? 'correct' : 'incorrect'}`;
            
            checkBtn.textContent = 'Continue';
            checkBtn.disabled = false;
            
            checkBtn.onclick = () => {
                this.onAnswer(isCorrect);
            };
        });
    }

    renderWordBankExercise(exercise) {
        const html = `
            <div class="exercise">
                <div class="exercise-type">Write this in ${app.currentLanguage}</div>
                <div class="exercise-question">${exercise.question}</div>
                <div class="answer-area" id="answerArea">
                    <span style="color: #999;">Tap the words to build your answer</span>
                </div>
                <div class="word-bank" id="wordBank">
                    ${exercise.words.map((word, index) => `
                        <button class="word-chip" data-index="${index}" data-word="${word}">
                            ${word}
                        </button>
                    `).join('')}
                </div>
                <button class="check-btn" disabled>Check</button>
                <div class="feedback"></div>
            </div>
        `;
        
        this.container.innerHTML = html;
        this.setupWordBankListeners(exercise);
    }

    setupWordBankListeners(exercise) {
        const wordBank = this.container.querySelector('#wordBank');
        const answerArea = this.container.querySelector('#answerArea');
        const checkBtn = this.container.querySelector('.check-btn');
        const feedback = this.container.querySelector('.feedback');
        let selectedWords = [];
        
        wordBank.addEventListener('click', (e) => {
            if (e.target.classList.contains('word-chip') && !e.target.classList.contains('selected')) {
                const word = e.target.dataset.word;
                selectedWords.push(word);
                e.target.classList.add('selected');
                
                if (selectedWords.length === 1) {
                    answerArea.innerHTML = '';
                }
                
                const wordChip = document.createElement('button');
                wordChip.className = 'word-chip selected';
                wordChip.textContent = word;
                wordChip.onclick = () => {
                    const index = selectedWords.indexOf(word);
                    if (index > -1) {
                        selectedWords.splice(index, 1);
                        wordChip.remove();
                        
                        // Unselect in word bank
                        const bankChips = wordBank.querySelectorAll('.word-chip');
                        bankChips.forEach(chip => {
                            if (chip.dataset.word === word && chip.classList.contains('selected')) {
                                chip.classList.remove('selected');
                            }
                        });
                        
                        if (selectedWords.length === 0) {
                            answerArea.innerHTML = '<span style="color: #999;">Tap the words to build your answer</span>';
                        }
                    }
                    checkBtn.disabled = selectedWords.length === 0;
                };
                
                answerArea.appendChild(wordChip);
                checkBtn.disabled = false;
            }
        });

        checkBtn.addEventListener('click', () => {
            const userAnswer = selectedWords.join(' ');
            const correctAnswer = exercise.correct.join(' ');
            const isCorrect = userAnswer === correctAnswer;
            
            feedback.textContent = isCorrect ? 
                '✓ Perfect!' : 
                `✗ Correct answer: ${correctAnswer}`;
            feedback.className = `feedback show ${isCorrect ? 'correct' : 'incorrect'}`;
            
            checkBtn.textContent = 'Continue';
            checkBtn.disabled = false;
            
            checkBtn.onclick = () => {
                this.onAnswer(isCorrect);
            };
        });
    }

    onAnswer(isCorrect) {
        // This will be set by the app controller
    }
}

// Practice Exercise Generator
class PracticeGenerator {
    static generateMistakeReview() {
        return [
            {
                type: "translate",
                question: "Review: What does 'Hola' mean?",
                options: ["Hello", "Goodbye", "Thanks", "Please"],
                correct: 0
            }
        ];
    }

    static generateListeningPractice() {
        return [
            {
                type: "listening",
                question: "What do you hear?",
                audio: "Buenos días",
                options: ["Good morning", "Good night", "Good afternoon", "Good evening"],
                correct: 0
            }
        ];
    }

    static generateSpeakingPractice() {
        return [
            {
                type: "translate",
                question: "Say: 'Good morning'",
                options: ["Buenos días", "Buenas noches", "Buenas tardes", "Hasta luego"],
                correct: 0
            }
        ];
    }

    static generateVocabularyReview() {
        return [
            {
                type: "wordbank",
                question: "Match: 'Thank you'",
                words: ["Gracias", "Por", "favor", "De", "nada"],
                correct: ["Gracias"]
            }
        ];
    }
}
